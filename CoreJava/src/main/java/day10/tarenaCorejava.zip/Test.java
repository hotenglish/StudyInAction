public class Test{
	public static void main(String[] args){
		//1首先在栈空间里声明了一个引用
		Student s = null; 
		//2. 在堆空间里申请了一个Student类对象的空间
		//3.申请Student空间以后，马上执行构造方法
		//4.执行构造方法以后，马上将这段空间的地址赋值给s引用
		s = new Student();
		
		Student s2 = new Student();
		System.out.println(s.age);
		System.out.println(s.name);
	}
}
class Student{
	String name;
	int age;
	//第一。不是用来生成对象的
	//第二 是用来初始化对象的
	Student(){
		name = "wangchao";
		age = 15;
	}
	public void study(){
		System.out.println("ljlj");
	}
}

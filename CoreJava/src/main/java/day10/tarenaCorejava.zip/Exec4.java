public class Exec4{
	public static void main(String[] args){
		SalariedEmployee se = new SalariedEmployee("wangchao",3,150);
		for( int i = 1; i <= 12; i++ ){
			System.out.println(se.getSalary(i));
		}
		HourlyEmployee he = new HourlyEmployee("kjljk",4,30,170);
	
		for( int j = 1; j <= 12; j++ ){
			System.out.println(he.getSalary(j));
		}
	}
}

class Employee{
	private String name;
	private int month;
	public Employee( String name, int month){
		this.name = name;
		this.month = month;
	}
	public double getSalary( int month ){
		return 0;
	}
	public String getName(){
		return name;
	}
	public void setName( String name){
		this.name = name;
	}
	public int getMonth(){
		return month;
	}
	public void setMonth(int month){
		this.month = month;
	}
}
class SalariedEmployee extends Employee{
	private double salary;
	public SalariedEmployee( String name, int month, double salary){
		super( name, month );
		this.salary = salary;
	}
	public double getSalary(int month){
		if( month==getMonth()) 
			return salary+100;
		else
			return salary;
	}
	public void setSalary( int salary ){
		this.salary = salary;
	}
	
}
class HourlyEmployee extends Employee{
	private double salaryAnHour;
	private int hourAnMonth;
	public HourlyEmployee( String name, int month, double salaryAnHour,int hourAnMonth ){
		super( name, month );
		this.salaryAnHour = salaryAnHour;
		this.hourAnMonth = hourAnMonth;
	}
	public double salaryAnHour(){
		return salaryAnHour;
	}
	public void setSalaryAnHour(int salaryAnHour){
		this.salaryAnHour = salaryAnHour;
	}
	public int hourAnMonth(){
		return hourAnMonth;
	}
	public void setHourAnMonth(int hourAnMonth){
		this.hourAnMonth = hourAnMonth;
	}
	public double getSalary( int month ){
		if( month  == getMonth()){
			if( salaryAnHour > 160){
				 return 160*salaryAnHour+(salaryAnHour-160)*1.5*salaryAnHour+100;
			}else{
				return salaryAnHour*hourAnMonth+100;
			}
		}else{
			if( salaryAnHour > 160){
				 return 160*salaryAnHour+(salaryAnHour-160)*1.5*salaryAnHour;
			}else{
				return salaryAnHour*hourAnMonth;
			}
		}
	}

}

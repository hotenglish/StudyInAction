public class Test4{
	public static void main(String[] args){
		Animal a = new Animal( "metenux" );
		People p =  new People("sd0706");
		Student s = new Student("asd706");
		
		hotel( a );
		hotel(p);
		hotel(s);

		Animal aa[] = new Animal[3];
		aa[0] = new Animal("1");
		aa[1] = new People("2");
		aa[2] = new Student("3");
		hotel( aa[0] );
		hotel( aa[1] );
		hotel( aa[2] );
	}
	public static void hotel(  Animal a ){
		System.out.println(  a.getName()+" is in hotle" );
	} 

}
class Animal{
	private String name;
	public String getName(){
		return name;
	}
	public Animal( String name ){
		this.name = name;
		System.out.println("Animal constructor");
	}
}
class People extends Animal{
	public People(String name){
		super( name );
		System.out.println("People constructor");
	}

}
class Student extends People {
	//是在类对象生成以后才执行，它比构造方法先执行
	{
		System.out.println("-----------------------------------");
		
	}
	public Student(String name){
		super(name);
		System.out.println(" a Student Construted");
	}
}

public class Test3{
	public static void main(String[] args){
		//1首先在栈空间里声明了一个引用
		Student s = null; 
		//2. 在堆空间里申请了一个Student类对象的空间
		//3.申请Student空间以后，马上执行构造方法
		//4.执行构造方法以后，马上将这段空间的地址赋值给s引用
		s = new Student();
		
	}

}
//1. 当构造一个对象时，构造方法的执行是按照由父类－》子类的顺序执行的
//2.当生成一个student对象的时候，虚拟机会去判断student对象是否存在父类，确实存在一个People的父类，然后虚拟机就会有执行People类构造方法的趋势，此时虚拟机还会去判断People是否有父类，确实存在一个叫Animal的父类，然后虚拟机就会有执行Animal构造方法的趋势，虚拟机继续判断Animal使否存在父类，确实不存在了，OK，先执行Animal的构造方法，返回到People执行People的构造方法，然后再返回到Student,执行Student的构造方法，这实际上就是一个递归构造的过程。
class Animal{

	public Animal(){
		System.out.println("Animal constructor");
	}
}
class People extends Animal{
	public People(){
		System.out.println("People constructor");
	}

}
class Student extends People{
	//是在类对象生成以后才执行，它比构造方法先执行
	{
		System.out.println("-----------------------------------");
		
	}
	public Student(){
		System.out.println(" a Student Construted");
	}
}

public class Test5{
	public static void main(String[] args){
		Student s = new Student();
		System.out.println(s.getAge());
		System.out.println(s.getName());
	}
}
class People{
	private int age;
	public People( int age ){
		this.age = age;
	} 
	public People(){
	}
	public int getAge(){
		return age;
	}
	
}
class Student extends People{
	private String name;
	public Student(){
		this("kjlk");
	}
	public Student( String name){
		super(15);	
		this.name = name;
	}
	public String getName(){
		return name;
	}
	
}

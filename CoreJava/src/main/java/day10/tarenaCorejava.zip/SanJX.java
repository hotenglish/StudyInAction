public class SanJX{
	public static void main(String[] args){
		print(1,9);
	}
	public static void print(int i, int n){
		if( i > n ){
			System.exit(0);
		}else{
			for( int k = 0; k < kongge( i, n ); k++ )
				System.out.print(' ');
			for( int j = 0; j < 2*i-1; j++)
				System.out.print("*");
			System.out.println();
			print(++i, n );
			
		}
	}
	public static int kongge(int i, int n){
		return n-i;
	}
	
}

    /* 
    *1
   ***2
  *****3
 *******4
*********5
*/

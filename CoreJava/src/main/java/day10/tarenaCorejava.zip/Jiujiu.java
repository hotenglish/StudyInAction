public class Jiujiu{
	public static void main(String[] args){
		fun( 1, 1 );
	}
	public static void fun( int i, int j ){
		if( j > 9 ){
			System.exit(0);
		}else{
			if( i < j ){
				System.out.print(i+"*"+j+"="+i*j+" ");
				fun(++i, j );
			}
				System.out.println(i+"*"+j+"="+i*j);
				fun(1, ++j);
		}
	}
}

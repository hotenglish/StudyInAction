public class Chuquan{
	public static void main(String[] args){
		int arrSrc[]  = new int[5];
		for( int i = 0; i < 5; i++ )
			arrSrc[i]=i;
		
		chuquan( arrSrc, 3 );
	}
	public static void chuquan(int[] arrSrc, int m){
		if( arrSrc.length == 0 ){
			System.exit(0);
		}
		int pos = pos( arrSrc.length, m );
		System.out.println(arrSrc[pos]);
		int arrDest[] = new int[arrSrc.length-1];
		if( pos==0 ){
			System.arraycopy(arrSrc,1, arrDest, 0, arrSrc.length-1 );		
			chuquan( arrDest, m );
		}else if( pos == arrSrc.length-1){
			System.arraycopy(arrSrc,0, arrDest, 0, arrSrc.length-1 );		
			chuquan( arrDest, m );
		}else{
			System.arraycopy(arrSrc,pos+1, arrDest, 0, arrSrc.length-1-pos );		
			System.arraycopy(arrSrc,0, arrDest,arrSrc.length-1-pos ,pos );		
			chuquan( arrDest, m );
		}
	
	}
	public static int pos(int length, int m){
		if( m < length|| length%m==0 )
			return m-1; 
		else 
			return length%m - 1;
	}
}

/*arrSrc:1 2 3 4 5
//另外声明一个数组，通过arrayCopy();
4 5 1 2*/



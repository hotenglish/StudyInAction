public class Test2{
	public static void main(String[] args){
		//1首先在栈空间里声明了一个引用
		Student s = null; 
		//2. 在堆空间里申请了一个Student类对象的空间
		//3.申请Student空间以后，马上执行构造方法
		//4.执行构造方法以后，马上将这段空间的地址赋值给s引用
		s = new Student();
		
	}
}
class Student{
	//是在类对象生成以后才执行，它比构造方法先执行
	{
		System.out.println("-----------------------------------");
		
	}
	public Student(){
		System.out.println(" a Student Construted");
	}
}

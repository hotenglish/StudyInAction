//这个测试类是由乙程序写的.
//并且甲程序告诉乙程序他所写的Stduent类有一个age属性和一个name属性。
public class Test6{
	public static void main(String[] args){
		Student s = new Student(22,"jlj");
		System.out.println( s.getAge() );

		Student[] ss = new Student[3];
		ss[0] = new Student(1,"wang");
		ss[1] = new Student(2,"chao");
		ss[2] = new Student(3,"wangchao");
		System.out.println( ss[0].getAge() );
		System.out.println( ss[1].getAge() );
		System.out.println( ss[2].getAge() );
		
		People[] pp = new People[3];
		pp[0] = new Student(23,"tomcat");
		pp[1] = new Teacher();
		pp[2] = new Teacher();
		
	}
}
//假设这个类是甲程序写的。
class People{
}
class Teacher extends People{
}
class Student extends People{
	private int age;
	private String name;
	public Student(int age, String name){
		setAge( age );
		setName( name);
	}
	public int getAge(){
		if( age > 40 ){
			return 20;
		}
		return age;
	}
	public void setAge( int age ){
		if( age > 100 ){
			System.out.println("the age is too large" );
			this.age = 25;
			return;
		}
		this.age = age;
	}
	public  String getName(){
		return name;
	}
	public void setName(String name){
		this.name = name;
	}
}

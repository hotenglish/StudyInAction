public class Digui{
	static int a = 0;
	public static void main(String[] args ){
		fun();
		System.out.println("a:"+a);
	}
	public static void fun(){
		if( a > 10 ){
			return;
		}
		a++;
		fun();
	}
}
